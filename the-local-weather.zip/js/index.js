if (navigator.geolocation){
navigator.geolocation.getCurrentPosition(function(position){
var skycons = new Skycons({"color": "green"});
var latitude = position.coords.latitude
var longitude = position.coords.longitude
var geolocation = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' + latitude + '%2C' + longitude + '&language=en';
var data;
var url = "https://api.darksky.net/forecast/e2cb814dd4e531fadcf785d19ad6aa64/" + latitude + "," + longitude + "?callback=?&units=si";
  $.getJSON(geolocation).done(function(location) {
        console.log(location);
       var location = location.results[0].address_components[1].long_name + ", " + location.results[0].address_components[3].long_name;
        $("#location").html(location);

      })

 $.getJSON(url, function(apidata) {
 
  data=apidata

$("#weather").html(data.currently.summary);
$("#temp").html(data.currently.temperature);
$("#icon").addClass(data.currently.icon);
   debugger;
      skycons.set("icon", data.currently.icon);
      skycons.play();
   
   console.log(data);
   });
   $('#fhBtn').click(function() {
var cel = data.currently.temperature;
$("#temp").html(Math.round(cel*1.8+32));
});

$('#clBtn').click(function() {
var cel = data.currently.temperature;
$("#temp").html(cel);
});
  var current = $.now();
var maxDate = new Date(current);
var currenDate = maxDate.toString();
$("#date").html(currenDate);
   });
}