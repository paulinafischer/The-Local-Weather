A Pen created at CodePen.io. You can find this one at https://codepen.io/paulinafischer/pen/PjGZgO.

 freeCodeCamp Intermediate front end develoment proyect.